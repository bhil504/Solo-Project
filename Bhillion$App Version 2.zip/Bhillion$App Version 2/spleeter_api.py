from flask import Flask, request, jsonify
from spleeter.separator import Separator
import os

app = Flask(__name__)

# Instantiate Spleeter with 2 stems (vocals and accompaniment)
separator = Separator('spleeter:2stems')

@app.route('/separate', methods=['POST'])
def separate():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    # Save the uploaded file
    input_path = os.path.join('input', file.filename)
    output_path = os.path.join('output', os.path.splitext(file.filename)[0])
    os.makedirs('input', exist_ok=True)
    os.makedirs('output', exist_ok=True)
    file.save(input_path)

    # Use Spleeter to separate the audio file
    separator.separate_to_file(input_path, 'output')

    return jsonify({'status': 'success', 'output_path': output_path})

if __name__ == '__main__':
    app.run(port=5000, debug=True)
