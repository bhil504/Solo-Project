package com.example.soloproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoloprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
