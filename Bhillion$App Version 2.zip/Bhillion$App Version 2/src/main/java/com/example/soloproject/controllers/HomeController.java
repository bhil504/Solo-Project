package com.example.soloproject.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.soloproject.models.LoginUser;
import com.example.soloproject.models.Tracks;
import com.example.soloproject.models.User;
import com.example.soloproject.services.TracksService;
import com.example.soloproject.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {
	@Autowired
	private UserService uService;
	@Autowired
	private TracksService tService;
	@Autowired
	HttpSession session;
 
	//Login and Registration Page
	 @GetMapping("/")
	 public String index(Model model) 
	 {
	     model.addAttribute("newUser", new User());
	     model.addAttribute("newLogin", new LoginUser());
	     return "LoginAndRegister.jsp";
	 }
	 
	 //Route to add the new User to the database. Also, checks for any errors in the entry beforehand and shows validations if "errors" are detected. See User Model for "errors" details.
	 @PostMapping("/register")
	 public String registerUser(@Valid @ModelAttribute("newUser") User newUser, 
	         BindingResult result, Model model, HttpSession session) 
	 {
	     
		 uService.register(newUser, result);
	     
	     if(result.hasErrors()) {
	         model.addAttribute("newLogin", new LoginUser());
	         return "LoginAndRegister.jsp";}
	     
	     else {
	     session.setAttribute("userId", newUser.getId());
	     return "redirect:/welcome";}
	 }
	 
	 //Route to retrieve the User from the database. Also, checks for any errors in the entry beforehand and shows validations if "errors" are detected. See User Model for "errors" details.
	 @PostMapping("/login")
	 public String loginUser(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
	         BindingResult result, Model model, HttpSession session) 
	 {
	     
	     User user = uService.login(newLogin, result);
	 
	     if(result.hasErrors()) {
	         model.addAttribute("newUser", new User());
	         return "LoginAndRegister.jsp";}
	     
	     else {
	     session.setAttribute("userId", user.getId());
	     return "redirect:/welcome";}
	 }
	 
	 //Main page displaying Logged in User and all song entries
	 @GetMapping("/welcome")
	 public String Dashboard(@ModelAttribute("track")Tracks track, HttpSession session, Model model)
	 {
			Long userId = (Long) session.getAttribute("userId");
			if(userId==null) {
				return "redirect:/";
			}
			
			else {
			
			User user = uService.getUserByID(userId);
			
			model.addAttribute("user",user);
			
			List<Tracks> tracks = tService.alltracks();
			model.addAttribute("tracks", tracks);
			
			return "Dashboard.jsp";}
		}
	 
	 
	 
	 @GetMapping("/logout")
	 public String logOut(HttpSession session) {
	 session.invalidate();
	 //to keep information but still logout (session.setAttribute("userID", null);)
	 return "redirect:/";
 }

 
	}
	
	 
