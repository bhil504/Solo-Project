package com.example.soloproject.services;

import com.example.soloproject.models.Tracks;
import com.example.soloproject.repositories.TracksRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.builder.FFmpegBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Service
public class FileConversionService {

    private final FFmpeg ffmpeg;
    private final FFmpegExecutor executor;

    @Autowired
    private TracksRepository tracksRepository;

    public FileConversionService() throws IOException {
        this.ffmpeg = new FFmpeg();
        this.executor = new FFmpegExecutor(ffmpeg);
    }

    @Async
    public void convertToMp3Async(MultipartFile file, Tracks track) {
        try {
            // Convert the uploaded file to MP3
            File tempMp3File = convertToMp3(file);
            byte[] fileData = Files.readAllBytes(tempMp3File.toPath());

            // Update the track with converted file data and set status to COMPLETED
            track.setFileData(fileData);
            track.setFileName(file.getOriginalFilename().replaceFirst("\\..*$", ".mp3"));
            track.setStatus("COMPLETED");

            // Save the updated track
            tracksRepository.save(track);

            // Clean up temp files
            cleanUp(tempMp3File);
        } catch (IOException e) {
            // Log the error
            e.printStackTrace();
            track.setStatus("FAILED");
            tracksRepository.save(track);
        }
    }

    @Async
    public void convertToWavAsync(File inputFile, Tracks track) {
        try {
            // Convert the file to WAV
            File tempWavFile = convertToWav(inputFile);
            byte[] fileData = Files.readAllBytes(tempWavFile.toPath());

            // Update the track with converted file data
            track.setFileData(fileData);
            track.setFileName(inputFile.getName().replaceFirst("\\..*$", ".wav"));

            // Save the updated track
            tracksRepository.save(track);

            // Clean up temp files
            cleanUp(tempWavFile);
        } catch (IOException e) {
            // Log the error (you could use a logging framework here)
            e.printStackTrace();
        }
    }

    // Convert file to MP3
    public File convertToMp3(MultipartFile inputFile) throws IOException {
        // Create a temp file for the input
        File tempInputFile = File.createTempFile("input", ".wav");
        inputFile.transferTo(tempInputFile);

        // Create a temp file for the output
        File tempOutputFile = File.createTempFile("output", ".mp3");

        // Build the ffmpeg command
        FFmpegBuilder builder = new FFmpegBuilder()
                .setInput(tempInputFile.getAbsolutePath())
                .overrideOutputFiles(true)
                .addOutput(tempOutputFile.getAbsolutePath())
                .setAudioCodec("libmp3lame") // Set codec for mp3
                .setAudioBitRate(320000)
                .done();

        // Execute the command
        executor.createJob(builder).run();

        return tempOutputFile;
    }

    // Convert file to WAV
    public File convertToWav(File inputFile) throws IOException {
        // Create a temp file for the output
        File tempOutputFile = File.createTempFile("output", ".wav");

        // Build the ffmpeg command
        FFmpegBuilder builder = new FFmpegBuilder()
                .setInput(inputFile.getAbsolutePath())
                .overrideOutputFiles(true)
                .addOutput(tempOutputFile.getAbsolutePath())
                .setAudioCodec("pcm_s16le") // Set codec for wav
                .done();

        // Execute the command
        executor.createJob(builder).run();

        return tempOutputFile;
    }

    // Clean up temp files if needed
    public void cleanUp(File file) {
        if (file != null && file.exists()) {
            file.delete();
        }
    }
    
    
    
    @Async
    public void separateAudioWithSpleeter(MultipartFile file, Tracks track) {
        try {
            // Convert MultipartFile to File
            File tempFile = File.createTempFile("spleeter_input", ".mp3");
            file.transferTo(tempFile);

            // Set up RestTemplate to call the Spleeter API
            RestTemplate restTemplate = new RestTemplate();
            String url = "http://localhost:5000/separate";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            HttpEntity<FileSystemResource> requestEntity = new HttpEntity<>(new FileSystemResource(tempFile), headers);

            // Send POST request to Spleeter API
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                // Update track status to SEPARATED
                track.setStatus("SEPARATED");
                tracksRepository.save(track);
            } else {
                track.setStatus("FAILED");
                tracksRepository.save(track);
            }

        } catch (IOException e) {
            e.printStackTrace();
            track.setStatus("FAILED");
            tracksRepository.save(track);
        }
    }
}


