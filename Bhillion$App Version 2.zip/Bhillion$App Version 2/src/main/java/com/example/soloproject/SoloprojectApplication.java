package com.example.soloproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class SoloprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoloprojectApplication.class, args);
	}

}
