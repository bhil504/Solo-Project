package com.example.soloproject.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

import com.example.soloproject.models.Tracks;
import com.example.soloproject.models.User;
import com.example.soloproject.services.FileConversionService;
import com.example.soloproject.services.TracksService;
import com.example.soloproject.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/tracks")
public class TrackController {

    @Autowired
    private TracksService tracksService;

    @Autowired
    private UserService userService;
    
    @Autowired
    private FileConversionService fileConversionService;

    @Autowired
    HttpSession session;
    
  //Route to the Display Page of a song
  	 @GetMapping("/{id}")
  	 public String showTrack(@PathVariable("id") Long id, Model model, HttpSession session) {
  		 
  		 Long userId = (Long) session.getAttribute("userId");
  			if(userId==null) {
  				return "redirect:/";
  			}else {
  		 
  		 model.addAttribute("track", tracksService.getTracksByID(id));
  		 return "showTrack.jsp";}
  	 }
    
  //Route to display the form for creating a new song
  	 @GetMapping("/new")
  	 public String newTrack(@ModelAttribute("track")Tracks track, HttpSession session, Model model) {
  		 
  		 Long userId = (Long) session.getAttribute("userId");
  			if(userId==null) {
  				return "redirect:/";
  			}

  		 return "newTrack.jsp";
  	 }
  	 
  	//Route to the Edit page of the song
  		 @GetMapping("/{id}/edit")
  		 public String editTrack(@PathVariable("id") Long id, Model model) {
  			 
  			 Long userId = (Long) session.getAttribute("userId");
  				if(userId==null) {
  					return "redirect:/";
  				}
  		        
  		        model.addAttribute("tracks", tracksService.getTracksByID(id));
  		        
  		        return "editTrack.jsp";
  		    }
  		 
  		@DeleteMapping("/delete/{trackId}")
		 public String deleteTrack (@PathVariable ("trackId") Long id) {
			 tracksService.deleteTrack(id);
			 return "redirect:/welcome";
		 }
  		
  	//Route to handle the file upload via the form and add to the database
  		@PostMapping("/upload-track")
  		public String uploadTrack(@RequestParam("file") MultipartFile file,
  		                           @Valid @ModelAttribute("track") Tracks track,
  		                           BindingResult result,
  		                           HttpSession session, Model model) {

  		    Long userId = (Long) session.getAttribute("userId");

  		    if (userId == null) {
  		        return "redirect:/";
  		    }

  		    // Validate inputs
  		    if (result.hasErrors()) {
  		        model.addAttribute("errorMessage", "All fields are required!");
  		        return "newTrack.jsp";
  		    }

  		    try {
  		        // Validate file size (16 MB max)
  		        if (file.getSize() > 16 * 1024 * 1024) {
  		            model.addAttribute("errorMessage", "File size exceeds the maximum limit of 16 MB.");
  		            return "newTrack.jsp";
  		        }

  		        // Set initial status to PENDING
  		        track.setStatus("PENDING");

  		        // Retrieve the user and associate it with the track
  		        User user = userService.getUserByID(userId);
  		        track.setUser(user);

  		        // Save the track initially with status PENDING
  		        tracksService.createTrack(track);

  		        // Queue the file for conversion asynchronously
  		        fileConversionService.convertToMp3Async(file, track);

  		        // Optionally, queue the file for separation using Spleeter
  		        fileConversionService.separateAudioWithSpleeter(file, track);

  		        // Redirect to the dashboard after successful upload
  		        return "redirect:/welcome";
  		    } catch (Exception e) {
  		        model.addAttribute("errorMessage", "Error processing the file.");
  		        return "newTrack.jsp";
  		    }
  		}

  		 
  		//Route to update an existing track in the database including file and file name
  		 @PutMapping("/update/{id}")
  		 public String updateTrack(@PathVariable Long id,
  		                          @Valid @ModelAttribute("tracks") Tracks tracks,
  		                          BindingResult result,
  		                          @RequestParam("file") MultipartFile file,
  		                          HttpSession session, Model model) { // Add HttpSession parameter

  		     Long userId = (Long) session.getAttribute("userId");

  		     if (userId == null) {
  		         return "redirect:/";
  		     }
  		     //Checks to see if the Track exists if not returns an errorPage.jsp
  		     Tracks existingTrack = tracksService.getTracksByID(id);
  		     if (existingTrack == null) {
  		         model.addAttribute("errorMessage", "Track not found.");
  		         return "errorPage.jsp";
  		     }
  		     
  		     // Return to form if there are validation errors
  		     if (result.hasErrors()) {
  		         model.addAttribute("tracks", tracks);
  		         return "editTrack.jsp"; 
  		     }

  		     // Update track information
  		     try {
  		         existingTrack.setTitle(tracks.getTitle());
  		         existingTrack.setGenre(tracks.getGenre());

  		         // Handle file upload logic
  		         if (file != null && !file.isEmpty()) {
  		             existingTrack.setFileName(file.getOriginalFilename());
  		             existingTrack.setFileData(file.getBytes());
  		         }

  		         // Update the track using the service method
  		         tracksService.updateTrack(id, existingTrack, file);
  		         model.addAttribute("successMessage", "Track updated successfully!");

  		     } catch (IOException e) {
  		         model.addAttribute("errorMessage", "Error processing the file.");
  		         return "editTrack.jsp"; // Return to form if there's an error
  		     }

  		     return "redirect:/welcome";
  		 }
  		 
  		 
  		@GetMapping("/download/{trackId}")
  	    public ResponseEntity<byte[]> downloadFile(@PathVariable("trackId") Long trackId, @RequestParam(value = "format", required = false, defaultValue = "mp3") String format) throws IOException {
  	        Tracks track = tracksService.getTracksByID(trackId);
  	        
  	        if (track == null || track.getFileData() == null) {
  	            return ResponseEntity.notFound().build();
  	        }
  	        
  	        byte[] fileData = track.getFileData();
  	        String fileName = track.getTitle();
  	        
  	        // Check if WAV format is requested
  	        if ("wav".equalsIgnoreCase(format)) {
  	            if (!track.getFileName().endsWith(".wav")) {
  	                // Convert to WAV if the original file is not in WAV format
  	                File tempMp3File = File.createTempFile("tempTrack", ".mp3");
  	                tempMp3File.deleteOnExit();
  	                Files.write(tempMp3File.toPath(), fileData);
  	                File convertedWavFile = fileConversionService.convertToWav(tempMp3File);
  	                fileData = Files.readAllBytes(convertedWavFile.toPath());
  	                fileName += ".wav";
  	                fileConversionService.cleanUp(tempMp3File);
  	                fileConversionService.cleanUp(convertedWavFile);
  	            } else {
  	                fileName += ".wav";
  	            }
  	        } else {
  	            fileName += ".mp3";
  	        }
  	        
  	        HttpHeaders headers = new HttpHeaders();
  	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
  	        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
  	        
  	        return new ResponseEntity<>(fileData, headers, HttpStatus.OK);
  	    }

    
    
}