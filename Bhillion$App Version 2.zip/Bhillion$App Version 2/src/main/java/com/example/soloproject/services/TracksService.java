package com.example.soloproject.services;

import com.example.soloproject.models.Tracks;
import com.example.soloproject.repositories.TracksRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class TracksService {

    @Autowired
    private TracksRepository tracksRepository;

    public TracksService(TracksRepository tracksRepository) {
        this.tracksRepository = tracksRepository;
    }
    
    // Create a new track
    public Tracks createTrack(Tracks track) {
        return tracksRepository.save(track);
    }

    // Retrieve all tracks
    public List<Tracks> alltracks() {
        return tracksRepository.findAll();
    }

    // Retrieve a track by ID
    public Tracks getTracksByID(Long id) {
        Optional<Tracks> track = tracksRepository.findById(id);
        return track.orElse(null); // Handle track not found
    }

    // Update an existing track
    public Tracks updateTrack(Long id, Tracks track, MultipartFile file) throws IOException {
        Tracks existingTrack = tracksRepository.findById(id).orElse(null);

        if (existingTrack != null) {
            // Update fields
            existingTrack.setTitle(track.getTitle());
            existingTrack.setGenre(track.getGenre());
            existingTrack.setLyrics(track.getLyrics());

            if (file != null && !file.isEmpty()) {
                existingTrack.setFileData(file.getBytes());
                existingTrack.setFileName(file.getOriginalFilename());
            }

            return tracksRepository.save(existingTrack); // Save updated track
        }
        return null; // Handle case where track is not found
    }

    public List<Tracks> getAllTracks() {
        return tracksRepository.findAll();
    }

    public Optional<Tracks> getTrackByID(Long id) {
        return tracksRepository.findById(id); // Return Optional for better handling
    }

    public void deleteTrack(Long id) {
        tracksRepository.deleteById(id);
    }
    
    public void saveTrack(Tracks track) {
        // Save the track to the database
        tracksRepository.save(track);
    }

    // Other service methods can be added as needed
}